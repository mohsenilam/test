package com.evolvestudio.autoexpert

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Color as GColor
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

private val bg = Color(0xFF07111D)
private val panel = Color(0xFF101F30)
private val line = Color(0xFF263D55)
private val red = Color(0xFFEF233C)
private val green = Color(0xFF18A66A)
private val ink = Color(0xFFEAF1F8)
private val muted = Color(0xFF9BAFC2)

data class CheckItem(val title: String, var status: Int = 0) // 0 blank, 1 approved, -1 rejected
data class Inspection(
    val id: String, var customer: String, var phone: String, var brand: String, var model: String,
    var year: String, var plate: String, var vin: String, var date: String,
    var body: MutableList<CheckItem>, var technical: MutableList<CheckItem>, var notes: String
)

private val bodyItems = listOf("رنگ و کیفیت رنگ بدنه", "بررسی رنگ‌شدگی و تعویض قطعات", "وضعیت درها، کاپوت و صندوق", "شیشه‌ها و فریم‌ها", "چراغ‌ها (جلو و عقب)", "سقف و ستون‌ها", "شاسی و کف خودرو", "محل جوش‌ها و نقاط اتصال", "بررسی ضربه و تصادف (سابقه تعمیر)", "راستای بدنه و تراز بودن درها", "وضعیت گلگیرها و رکاب‌ها", "لچکی‌ها و قطعات پلاستیکی", "زیر خودرو (کف و شاسی)", "آب‌بندی و نشتی‌ها", "وضعیت شاسی‌کشی و تقویت‌ها", "کیفیت لاستیک و رینگ‌ها", "وضعیت باربند و قطعات جانبی", "سایر موارد بدنه و شاسی")
private val techItems = listOf("وضعیت موتور و نشتی روغن", "عملکرد و سلامت گیربکس", "سیستم خنک‌کننده (رادیاتور و ترموستات)", "سیستم سوخت‌رسانی (پمپ و انژکتور)", "سیستم برق و باتری", "دینام و سیستم شارژ", "ترمزها (کفشک/دیسک و لنت)", "سیستم تعلیق و جلوبندی", "سیستم فرمان", "لاستیک‌ها و رینگ‌ها", "اگزوز و سیستم انتشارات", "کولر و سیستم تهویه", "گرم‌کن و بخاری", "عملکرد نشانگرها و صفحه کیلومتر", "سیستم ایمنی (ایربگ و کمربند)", "سلامت شیشه‌بالابرها و قفل مرکزی", "سیستم صوتی و تجهیزات داخلی", "سایر موارد فنی")

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("autoexpert", MODE_PRIVATE) }
    private fun loadArchive(): MutableList<Inspection> {
        val arr = JSONArray(prefs.getString("archive", "[]"))
        return MutableList(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            fun readItems(key: String) = MutableList(o.getJSONArray(key).length()) { j ->
                val x = o.getJSONArray(key).getJSONObject(j); CheckItem(x.getString("title"), x.getInt("status"))
            }
            Inspection(o.getString("id"),o.optString("customer"),o.optString("phone"),o.optString("brand"),o.optString("model"),o.optString("year"),o.optString("plate"),o.optString("vin"),o.optString("date"),readItems("body"),readItems("technical"),o.optString("notes"))
        }.reversed().toMutableList()
    }
    private fun persist(list: List<Inspection>) {
        val arr = JSONArray()
        list.forEach { v ->
            val o = JSONObject().put("id",v.id).put("customer",v.customer).put("phone",v.phone).put("brand",v.brand).put("model",v.model).put("year",v.year).put("plate",v.plate).put("vin",v.vin).put("date",v.date).put("notes",v.notes)
            fun putItems(k:String, items:List<CheckItem>) { val a=JSONArray(); items.forEach { a.put(JSONObject().put("title",it.title).put("status",it.status)) }; o.put(k,a) }
            putItems("body",v.body); putItems("technical",v.technical); arr.put(o)
        }
        prefs.edit().putString("archive",arr.toString()).apply()
    }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App(this, ::loadArchive, ::persist, ::exportReport) } }

    private fun exportReport(v: Inspection, type: String) {
        val width=1240; val height=1754
        val bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888); val c=Canvas(bmp)
        drawReport(c,v,width,height)
        val resolver=contentResolver
        val values=ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME,"AutoExpert_${v.plate.ifBlank { v.id }}.$type"); put(MediaStore.MediaColumns.MIME_TYPE,if(type=="pdf") "application/pdf" else "image/png"); put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/AutoExpert") }
        val uri=resolver.insert(if(type=="pdf") MediaStore.Files.getContentUri("external") else MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values) ?: return
        resolver.openOutputStream(uri)?.use { out ->
            if(type=="png") bmp.compress(Bitmap.CompressFormat.PNG,100,out) else {
                val doc=PdfDocument(); val page=doc.startPage(PdfDocument.PageInfo.Builder(width,height,1).create()); drawReport(page.canvas,v,width,height); doc.finishPage(page); doc.writeTo(out); doc.close()
            }
        }
        bmp.recycle()
    }

    private fun drawReport(c: Canvas, v: Inspection, w: Int, h: Int) {
        val p=Paint(Paint.ANTI_ALIAS_FLAG); c.drawColor(GColor.WHITE)
        fun text(s:String,x:Float,y:Float,size:Float,color:Int=GColor.BLACK,bold:Boolean=false,align:Paint.Align=Paint.Align.RIGHT) { p.color=color;p.textSize=size;p.typeface=if(bold) Typeface.create("sans-serif",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL);p.textAlign=align;c.drawText(s,x,y,p) }
        fun rect(l:Float,t:Float,r:Float,b:Float,color:Int,rad:Float=18f) { p.color=color;c.drawRoundRect(l,t,r,b,rad,rad,p) }
        rect(25f,25f,1215f,205f,GColor.rgb(7,17,29),24f); rect(930f,25f,1215f,205f,GColor.rgb(239,35,60),24f)
        text("مرکز کارشناسی خودرو",590f,112f,52f,GColor.WHITE,true,Paint.Align.CENTER); text("گزارش تخصصی کارشناسی خودرو",590f,165f,25f,GColor.LTGRAY,false,Paint.Align.CENTER)
        rect(25f,225f,1215f,350f,GColor.rgb(238,243,248),18f)
        val fields=listOf("مشتری: ${v.customer}","تماس: ${v.phone}","خودرو: ${v.brand} ${v.model}","مدل: ${v.year}","پلاک: ${v.plate}","شماره شاسی: ${v.vin}","تاریخ: ${v.date}")
        fields.forEachIndexed { i,s -> text(s,1180f-(i%2)*570f,270f+(i/2)*42f,23f,GColor.rgb(20,35,50),true) }
        fun table(items:List<CheckItem>,left:Float,top:Float,right:Float,title:String,accent:Int) {
            rect(left,top,right,top+58f,accent,12f); text(title,(left+right)/2,top+40f,30f,GColor.WHITE,true,Paint.Align.CENTER)
            val rowH=42f; items.forEachIndexed { i,it -> val y=top+58f+i*rowH; p.color=if(i%2==0) GColor.rgb(245,248,251) else GColor.rgb(229,236,242);c.drawRect(left,y,right,y+rowH,p)
                text(it.title,right-14f,y+29f,19f,GColor.rgb(15,30,45),false)
                val cx=left+34f; val cy=y+21f; p.style=Paint.Style.STROKE;p.strokeWidth=2f;p.color=if(it.status==1) GColor.rgb(24,166,106) else if(it.status==-1) GColor.rgb(239,35,60) else GColor.GRAY;c.drawRoundRect(cx-11,cy-11,cx+11,cy+11,3f,3f,p);p.style=Paint.Style.FILL
                if(it.status!=0) text(if(it.status==1) "✓" else "×",cx,cy+8f,24f,p.color,true,Paint.Align.CENTER)
                p.color=GColor.LTGRAY;p.strokeWidth=1f;c.drawLine(left,y+rowH,right,y+rowH,p)
            }
        }
        table(v.technical,25f,375f,610f,"کارشناسی فنی",GColor.rgb(7,17,29)); table(v.body,630f,375f,1215f,"کارشناسی بدنه و شاسی",GColor.rgb(205,15,37))
        val noteY=1220f; rect(25f,noteY,1215f,1650f,GColor.rgb(242,246,249),18f); text("توضیحات کارشناس",1180f,noteY+45f,29f,GColor.rgb(7,17,29),true)
        val lines=v.notes.chunked(82).take(8); lines.forEachIndexed { i,s -> text(s,1180f,noteY+95f+i*43f,22f,GColor.DKGRAY,false) }
        rect(25f,1670f,1215f,1735f,GColor.rgb(7,17,29),12f); text("شماره تماس: ${prefs.getString("phone","۰۹۱۸ xxx xxxx")}",1180f,1710f,22f,GColor.WHITE,true); text("آدرس: ${prefs.getString("address","ایلام، آدرس مرکز را در تنظیمات وارد کنید")}",610f,1710f,20f,GColor.WHITE,false,Paint.Align.CENTER)
    }
}

@Composable private fun App(activity: MainActivity, load:()->MutableList<Inspection>, save:(List<Inspection>)->Unit, export:(Inspection,String)->Unit) {
    var archive by remember { mutableStateOf(load()) }; var page by remember { mutableStateOf("home") }; var current by remember { mutableStateOf(newInspection()) }; var query by remember { mutableStateOf("") }; var themeChoice by remember { mutableIntStateOf(0) }
    val accent= when(themeChoice){1->Color(0xFF2878D0);2->Color(0xFF159B79);else->red}
    MaterialTheme(colorScheme=darkColorScheme(primary=accent,background=bg,surface=panel)) {
        Surface(Modifier.fillMaxSize(),color=bg) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().background(Color(0xFF0A1725)).padding(18.dp),verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("AUTOEXPERT",color=Color.White,fontWeight=FontWeight.Black,letterSpacing=2.sp,fontSize=20.sp); Text("مرکز کارشناسی خودرو",color=muted,fontSize=12.sp) }
                    Text("●",color=accent,fontSize=28.sp); Spacer(Modifier.width(8.dp)); Text("گزارش حرفه‌ای",color=ink,fontWeight=FontWeight.Bold)
                }
                when(page) {
                    "home" -> HomeScreen(archive.size,accent,{ current=newInspection();page="edit" },{page="archive"},{page="settings"})
                    "edit" -> EditScreen(current,accent,{ current=it },{ page="preview" },{ page="home" })
                    "preview" -> PreviewScreen(current,accent,{ export(current,"pdf") },{ export(current,"png") },{ val exists=archive.any{it.id==current.id}; archive.removeAll { it.id==current.id }; archive.add(0,current.copy(body=current.body.map{it.copy()}.toMutableList(),technical=current.technical.map{it.copy()}.toMutableList())); save(archive);page="home" },{page="edit"})
                    "archive" -> ArchiveScreen(archive,query,{query=it},{ v -> current=v.copy(body=v.body.map{it.copy()}.toMutableList(),technical=v.technical.map{it.copy()}.toMutableList());page="preview" },{page="home"})
                    else -> SettingsScreen(activity,accent,themeChoice,{themeChoice=it},{page="home"})
                }
                if(page!="edit" && page!="preview") Row(Modifier.fillMaxWidth().background(Color(0xFF0A1725)).padding(10.dp),horizontalArrangement=Arrangement.SpaceEvenly) {
                    NavItem("خانه",Icons.Default.Home,page=="home"){page="home"}; NavItem("بایگانی",Icons.Default.Folder,page=="archive"){page="archive"}; NavItem("تنظیمات",Icons.Default.Settings,page=="settings"){page="settings"}
                }
            }
        }
    }
}
private fun newInspection()=Inspection(UUID.randomUUID().toString().take(8),"","","","","","","",SimpleDateFormat("yyyy/MM/dd",Locale.US).format(Date()),bodyItems.map{CheckItem(it)}.toMutableList(),techItems.map{CheckItem(it)}.toMutableList(),"")

@Composable private fun HomeScreen(count:Int,accent:Color,new:()->Unit,archive:()->Unit,settings:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Box(Modifier.fillMaxWidth().height(190.dp).background(brush=androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF142A40),Color(0xFF07111D))),RoundedCornerShape(24.dp)).border(1.dp,line,RoundedCornerShape(24.dp)).padding(20.dp)) { Column(Modifier.align(Alignment.CenterStart)) { Text("کارشناسی دقیق،\nگزارش قابل اعتماد",fontSize=25.sp,fontWeight=FontWeight.Black,color=Color.White); Text("همه چیز برای یک گزارش حرفه‌ای",color=muted); Spacer(Modifier.height(12.dp)); Text("AUTOEXPERT  /  INSPECTION",color=accent,fontSize=11.sp,fontWeight=FontWeight.Bold) }; Icon(Icons.Default.DirectionsCar,null,Modifier.align(Alignment.CenterEnd).size(94.dp),tint=accent) } }
        item { Button(onClick=new,Modifier.fillMaxWidth().height(66.dp),colors=ButtonDefaults.buttonColors(containerColor=accent),shape=RoundedCornerShape(18.dp)) { Icon(Icons.Default.Add,null); Spacer(Modifier.width(8.dp)); Text("شروع کارشناسی جدید",fontSize=18.sp,fontWeight=FontWeight.Bold) } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) { HomeTile("بایگانی گزارش‌ها","$count گزارش ذخیره‌شده",Icons.Default.Folder,Modifier.weight(1f),archive); HomeTile("تنظیمات مرکز","اطلاعات و قالب",Icons.Default.Tune,Modifier.weight(1f),settings) } }
        item { Text("روال سریع کار",color=ink,fontWeight=FontWeight.Bold,fontSize=18.sp) }
        item { Text("۱. مشخصات خودرو را وارد کن   ۲. وضعیت‌ها را با یک لمس تعیین کن   ۳. گزارش را ذخیره و PDF یا PNG بگیر.",color=muted,lineHeight=24.sp) }
    }
}
@Composable private fun HomeTile(title:String,sub:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier,click:()->Unit) { Card(modifier.clickable{click()},colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(18.dp),border=BorderStroke(1.dp,line)) { Column(Modifier.padding(16.dp)) { Icon(icon,null,tint=red,modifier=Modifier.size(28.dp)); Spacer(Modifier.height(12.dp)); Text(title,color=ink,fontWeight=FontWeight.Bold); Text(sub,color=muted,fontSize=12.sp) } } }
@Composable private fun NavItem(label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,selected:Boolean,click:()->Unit) { Column(Modifier.clickable{click()}.padding(horizontal=18.dp, vertical=5.dp),horizontalAlignment=Alignment.CenterHorizontally) { Icon(icon,null,tint=if(selected) red else muted); Text(label,color=if(selected) red else muted,fontSize=11.sp) } }

@Composable private fun EditScreen(v:Inspection,accent:Color,update:(Inspection)->Unit,next:()->Unit,back:()->Unit) {
    var tab by remember { mutableIntStateOf(0) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(top=12.dp)) { Text("کارشناسی جدید",fontSize=22.sp,fontWeight=FontWeight.Bold,color=ink,modifier=Modifier.weight(1f)); TextButton(onClick=back){Text("بازگشت")} } }
        item { SectionTitle("مشخصات خودرو و مشتری") }
        item { Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            InputField("نام مشتری",v.customer){update(v.copy(customer=it))}; InputField("شماره تماس",v.phone,KeyboardType.Phone){update(v.copy(phone=it))}
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Box(Modifier.weight(1f)){InputField("برند خودرو",v.brand){update(v.copy(brand=it))} }; Box(Modifier.weight(1f)){InputField("مدل",v.model){update(v.copy(model=it))} } }
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Box(Modifier.weight(1f)){InputField("سال ساخت",v.year,KeyboardType.Number){update(v.copy(year=it))} }; Box(Modifier.weight(1f)){InputField("شماره پلاک",v.plate){update(v.copy(plate=it))} } }
            InputField("شماره شاسی (اختیاری)",v.vin){update(v.copy(vin=it))}
        } }
        item { Row(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(14.dp)).padding(5.dp),horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf("کارشناسی فنی","بدنه و شاسی").forEachIndexed{i,s->Box(Modifier.weight(1f).background(if(tab==i)accent else Color.Transparent,RoundedCornerShape(11.dp)).clickable{tab=i}.padding(12.dp),contentAlignment=Alignment.Center){Text(s,color=Color.White,fontWeight=FontWeight.Bold)} } } }
        val items=if(tab==0) v.technical else v.body
        item { Row(Modifier.fillMaxWidth().padding(horizontal=4.dp),verticalAlignment=Alignment.CenterVertically) { Text("موارد بررسی",color=ink,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f)); Text("تأیید",color=green,fontSize=12.sp); Spacer(Modifier.width(18.dp)); Text("عدم تأیید",color=red,fontSize=12.sp) } }
        itemsIndexed(items) { i,it -> Row(Modifier.fillMaxWidth().background(if(i%2==0) panel else Color(0xFF0C1927),RoundedCornerShape(12.dp)).border(1.dp,line,RoundedCornerShape(12.dp)).padding(horizontal=10.dp,vertical=8.dp),verticalAlignment=Alignment.CenterVertically) {
            Text("${i+1}. ${it.title}",color=ink,fontSize=13.sp,modifier=Modifier.weight(1f))
            StatusButton("✓",it.status==1,green){ val copy=items.map{it.copy()}.toMutableList();copy[i].status=if(it.status==1)0 else 1;update(if(tab==0)v.copy(technical=copy) else v.copy(body=copy)) }
            Spacer(Modifier.width(8.dp)); StatusButton("×",it.status==-1,red){ val copy=items.map{it.copy()}.toMutableList();copy[i].status=if(it.status==-1)0 else -1;update(if(tab==0)v.copy(technical=copy) else v.copy(body=copy)) }
        } }
        item { SectionTitle("توضیحات کارشناس") }
        item { OutlinedTextField(v.notes,{update(v.copy(notes=it))},Modifier.fillMaxWidth().heightIn(min=130.dp),placeholder={Text("توضیحات، ایرادها و پیشنهادهای کارشناس...")},colors=fieldColors(),shape=RoundedCornerShape(14.dp)) }
        item { Button(onClick=next,Modifier.fillMaxWidth().height(56.dp),colors=ButtonDefaults.buttonColors(containerColor=accent)){Text("پیش‌نمایش و ذخیره گزارش",fontWeight=FontWeight.Bold)}; Spacer(Modifier.height(20.dp)) }
    }
}
@Composable private fun StatusButton(label:String,active:Boolean,color:Color,click:()->Unit) { Box(Modifier.size(34.dp).background(if(active)color.copy(alpha=.18f) else Color(0xFF091522),RoundedCornerShape(9.dp)).border(1.dp,if(active)color else line,RoundedCornerShape(9.dp)).clickable{click()},contentAlignment=Alignment.Center){Text(label,color=color,fontSize=22.sp,fontWeight=FontWeight.Black)} }
@Composable private fun SectionTitle(s:String){ Text(s,color=ink,fontWeight=FontWeight.Bold,fontSize=16.sp,modifier=Modifier.padding(top=8.dp,bottom=2.dp)) }
@Composable private fun InputField(label:String,value:String,type:KeyboardType=KeyboardType.Text,onChange:(String)->Unit){ OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=type),colors=fieldColors(),shape=RoundedCornerShape(13.dp)) }
@Composable private fun fieldColors()=OutlinedTextFieldDefaults.colors(focusedTextColor=ink,unfocusedTextColor=ink,focusedBorderColor=red,unfocusedBorderColor=line,focusedLabelColor=red,unfocusedLabelColor=muted,cursorColor=red,focusedContainerColor=panel,unfocusedContainerColor=panel)

@Composable private fun PreviewScreen(v:Inspection,accent:Color,pdf:()->Unit,png:()->Unit,save:()->Unit,edit:()->Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically){Text("پیش‌نمایش گزارش",color=ink,fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));TextButton(onClick=edit){Text("ویرایش")}}
        Card(Modifier.weight(1f).fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color(0xFFF2F6F9)),shape=RoundedCornerShape(16.dp)) { LazyColumn(Modifier.padding(12.dp)) {
            item { Text("مرکز کارشناسی خودرو",color=Color(0xFF07111D),fontSize=22.sp,fontWeight=FontWeight.Black); Text("گزارش کارشناسی خودرو",color=Color.DarkGray) }
            item { Text("${v.brand} ${v.model} | ${v.year} | پلاک ${v.plate}\nمشتری: ${v.customer} | ${v.phone}",color=Color.DarkGray,modifier=Modifier.padding(vertical=12.dp)) }
            item { Text("کارشناسی فنی",color=Color(0xFF07111D),fontWeight=FontWeight.Bold) }
            items(v.technical.size){i->ReportLine(v.technical[i])}
            item { Spacer(Modifier.height(12.dp));Text("کارشناسی بدنه و شاسی",color=Color(0xFF07111D),fontWeight=FontWeight.Bold) }
            items(v.body.size){i->ReportLine(v.body[i])}
            item { Text("توضیحات: ${v.notes}",color=Color.DarkGray,modifier=Modifier.padding(top=14.dp)) }
        } }
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ Button(onClick=pdf,Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=green)){Icon(Icons.Default.PictureAsPdf,null);Text(" PDF")};Button(onClick=png,Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF2878D0))){Icon(Icons.Default.Image,null);Text(" PNG")};Button(onClick=save,Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=accent)){Icon(Icons.Default.Save,null);Text(" ذخیره") } }
    }
}
@Composable private fun ReportLine(it:CheckItem){Row(Modifier.fillMaxWidth().padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically){Text(it.title,color=Color(0xFF172536),fontSize=12.sp,modifier=Modifier.weight(1f));Text(if(it.status==1)"✓" else if(it.status==-1)"×" else "□",color=if(it.status==1)green else if(it.status==-1)red else Color.Gray,fontWeight=FontWeight.Black)}}

@Composable private fun ArchiveScreen(list:List<Inspection>,query:String,onQuery:(String)->Unit,open:(Inspection)->Unit,back:()->Unit){
    Column(Modifier.fillMaxSize().padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("بایگانی کارشناسی‌ها",color=ink,fontSize=21.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));TextButton(onClick=back){Text("خانه")}};OutlinedTextField(query,onQuery,Modifier.fillMaxWidth(),placeholder={Text("جست‌وجوی نام، خودرو یا پلاک")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,colors=fieldColors())
        LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp),modifier=Modifier.padding(top=12.dp)){items(list.filter{("${it.customer} ${it.brand} ${it.model} ${it.plate}").contains(query,true)}){v->Card(Modifier.fillMaxWidth().clickable{open(v)},colors=CardDefaults.cardColors(containerColor=panel),border=BorderStroke(1.dp,line)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.DirectionsCar,null,tint=red,modifier=Modifier.size(34.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("${v.brand} ${v.model} ${v.year}",color=ink,fontWeight=FontWeight.Bold);Text("${v.customer} • پلاک ${v.plate}",color=muted,fontSize=12.sp);Text(v.date,color=muted,fontSize=11.sp)};Icon(Icons.Default.ChevronLeft,null,tint=muted)}}} }
        if(list.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("هنوز گزارشی ذخیره نشده است",color=muted)}
    }
}
@Composable private fun SettingsScreen(activity:MainActivity,accent:Color,choice:Int,onChoice:(Int)->Unit,back:()->Unit){var phone by remember{mutableStateOf(activity.getSharedPreferences("autoexpert",0).getString("phone","")?:"")};var address by remember{mutableStateOf(activity.getSharedPreferences("autoexpert",0).getString("address","")?:"")}
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("تنظیمات مرکز",color=ink,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("اطلاعات ثابت فوتر گزارش",color=muted);InputField("شماره تماس مرکز",phone,KeyboardType.Phone){phone=it};InputField("آدرس مرکز",address){address=it};Text("انتخاب استایل برنامه",color=ink,fontWeight=FontWeight.Bold);listOf("قرمز اسپرت","آبی تکنولوژیک","سبز حرفه‌ای").forEachIndexed{i,s->Row(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(12.dp)).clickable{onChoice(i)}.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(14.dp).background(listOf(red,Color(0xFF2878D0),Color(0xFF159B79))[i],RoundedCornerShape(50)));Spacer(Modifier.width(12.dp));Text(s,color=ink,modifier=Modifier.weight(1f));RadioButton(choice==i,{onChoice(i)},colors=RadioButtonDefaults.colors(selectedColor=accent))}};Button(onClick={activity.getSharedPreferences("autoexpert",0).edit().putString("phone",phone).putString("address",address).apply();back()},Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=accent)){Text("ذخیره تنظیمات")};Text("نسخه اولیه ۱.۰ • اطلاعات بایگانی روی همین گوشی نگهداری می‌شود.",color=muted,fontSize=11.sp)}
}
