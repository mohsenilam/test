# ساخت APK فقط با گوشی و GitHub

1. در GitHub یک Repository جدید بسازید و نام آن را `AutoExpert` بگذارید. Public یا Private فرقی ندارد.
2. فایل `AutoExpert_Android_Project.zip` را در ریشه Repository آپلود کنید.
3. فایل `build-apk.yml` را در مسیر `.github/workflows/build-apk.yml` قرار دهید. اگر پوشه‌ها وجود ندارند، هنگام ساخت فایل جدید نام کامل مسیر را وارد کنید.
4. به زبانه Actions بروید، گردش‌کار **Build AutoExpert APK** را انتخاب کنید و روی **Run workflow** بزنید.
5. پس از سبز شدن اجرا، وارد همان اجرای موفق شوید و از بخش Artifacts فایل `AutoExpert-APK` را دانلود کنید.
6. ZIP دانلودشده را در گوشی باز کنید، `app-debug.apk` را نصب کنید و در صورت درخواست، اجازه نصب از منبع مرورگر/مدیریت فایل را فعال کنید.

اگر Build قرمز شد، از صفحه اجرای Actions تصویر خطا را بفرستید تا اصلاحش کنیم.
